module.exports = {

  name: "get_related_lists_metadata",

  title: "Get Related Lists Metadata",

  description: "To get the related list data of a particular module",
  version: "v1",

  input:{
    title: "Get Related Lists Metadata",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "related_lists":{
        "title": "related_lists",
        "type": "any",
        "displayTitle": "Related Lists"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts"
  },

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/related_lists",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs:{
        module: input.module_api_name
      }
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
