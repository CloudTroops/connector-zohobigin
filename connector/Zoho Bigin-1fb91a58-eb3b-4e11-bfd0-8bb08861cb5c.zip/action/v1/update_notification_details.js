module.exports = {

  name: "update_notification_details",

  title: "Update Notification Details",

  description: "To update the details of the notifications enabled by a user",
  version: "v1",

  input:{
    title: "Update Notification Details",
    type: "object",
    properties: {
      "watch":{
        "title": "watch",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "token":{
              "title": "token",
              "type": "string",
              "displayTitle": "Token"
            },
            "notify_url":{
              "title": "notify_url",
              "type": "string",
              "displayTitle": "Notify Url",
              "minLength": 1
            },
            "channel_id":{
              "title": "channel_id",
              "type": "string",
              "displayTitle": "Channel Id",
              "minLength": 1
            },
            "channel_expiry":{
              "title": "channel_expiry",
              "type": "string",
              "displayTitle": "Channel Expiry"
            },
            "events":{
              "title": "events",
              "type": "array",
              "displayTitle": "Events",
              "minLength": 1,
              "items": {
                "title": "module.operation",
                "type":"string",
                "properties":{
                               
                }
              }
            }          
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "watch":{
        "title": "watch",
        "type": "any",
        "displayTitle": "Watch"
      }
    }
  },

  mock_input:{
    "watch": [
      {
           "channel_id": "1000000068001",
           "events": [
               "Contacts.delete"
           ],
           "channel_expiry": "2023-10-02T10:30:00+05:30",
           "token": "TOKEN_FOR_VERIFICATION_OF_1000000068001",
           "notify_url": "https://www.zoho.com/callback"
       }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "watch": input.watch
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/actions/watch",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"        
      },
      method: "PUT",
      json: data     
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
