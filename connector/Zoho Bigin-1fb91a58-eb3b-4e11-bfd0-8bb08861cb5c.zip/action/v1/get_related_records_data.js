module.exports = {

  name: "get_related_records_data",

  title: "Get Related Records Data",

  description: "To get the related list records",
  version: "v1",

  input:{
    title: "Get Related Records Data",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "record_id":{
        "title": "record_id",
        "type": "string",
        "displayTitle": "Record Id",
        "minLength":1        
      },
      "related_list_api_name":{
        "title": "related_list_api_name",
        "type": "string",
        "displayTitle": "Related List API Name",
        "minLength":1        
      },
      "page":{
        "title": "page",
        "type": "number",
        "displayTitle": "Page"        
      },
      "per_page":{
        "title": "per_page",
        "type": "number",
        "displayTitle": "Per Page"        
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "record_id": "302774000000223767",
    "related_list_api_name": "Notes"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      
    }

    if (input.page){
      data["page"] = input.page 
    }

    if (input.per_page){
      data["per_page"] = input.per_page 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name + "/" + input.record_id + "/" + input.related_list_api_name,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs: data    
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
