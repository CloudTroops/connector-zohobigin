module.exports = {

  name: "get_modules",

  title: "Get Modules",

  description: "To retrieve the list of all the modules",
  version: "v1",

  input:{
    title: "Get Modules",
    type: "object",
    properties: {

    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "modules":{
        "title": "modules",
        "type": "any",
        "displayTitle": "Modules"
      }
    }
  },

  mock_input:{},

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/modules",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET"
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
