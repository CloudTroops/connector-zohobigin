module.exports = {

  name: "delete_records",

  title: "Delete Records",

  description: "To delete entities or records from a module",
  version: "v1",

  input:{
    title: "Delete Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "record_ids":{
        "title": "record_ids",
        "type": "string",
        "displayTitle": "Record Ids",
        "minLength":1
      },
      "wf_trigger":{
        "title": "wf_trigger",
        "type": "string",
        "displayTitle": "Wf Trigger",
        "enum": ["", "true", "false"]        
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "record_ids": "302774000000223869"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "ids": input.record_ids
    }

    if (input.wf_trigger){
      data["wf_trigger"] = input.wf_trigger 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "DELETE",
      qs: data   
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
