module.exports = {

  name: "update_records",

  title: "Update Records",

  description: "To update existing entities in the module",
  version: "v1",

  input:{
    title: "Update Records",
    type: "object",
    properties: {
      
      "module_name": {
        "type": "object",
        "title": "Module Name",
        "description": "Module Name",
        "oneOf": [{
            "title": "Contacts",
            "type": "object",
            "properties": {
              "type": {
                "type": "string",
                "readonly": true,
                "options": {
                  "hidden": true
              },
              "enum": [
                "Contacts"
              ]
            },
            "data":{
              "title": "Data",
              "type": "array",
              "items":{
                "type": "object",
                "properties":{
                  "id": {
                    "title": "Record Id",
                    "description": "Record Id",
                    "type": "string",
                    "minLength": 1
                  },
                  "Title": {
                    "title": "Title",
                    "description": "Title",
                    "type": "string"
                  },
                  "First_Name": {
                    "title": "First Name",
                    "description": "First Name",
                    "type": "string"
                  },
                  "Last_Name": {
                    "title": "Last Name",
                    "description": "Last Name",
                    "type": "string"
                  },
                  "Email": {
                    "title": "Email",
                    "description": "Email",
                    "type": "string"
                  },
                  "Mobile": {
                    "title": "Mobile",
                    "description": "Mobile",
                    "type": "string"
                  },
                  "Phone": {
                    "title": "Phone",
                    "description": "Phone",
                    "type": "string"
                  },
                  "Description": {
                    "title": "Description",
                    "description": "Description",
                    "type": "string"
                  },
                  "Full_Name": {
                    "title": "Full Name",
                    "description": "Full Name",
                    "type": "string"
                  },
                  "Mailing_Street": {
                    "title": "Mailing Street",
                    "description": "Mailing Street",
                    "type": "string"
                  },
                  "Mailing_City": {
                    "title": "Mailing City",
                    "description": "Mailing City",
                    "type": "string"
                  },
                  "Mailing_State": {
                    "title": "Mailing State",
                    "description": "Mailing State",
                    "type": "string"
                  },
                  "Mailing_Country": {
                    "title": "Mailing Country",
                    "description": "Mailing Country",
                    "type": "string"
                  },
                  "Mailing_Zip": {
                    "title": "Mailing Zip",
                    "description": "Mailing Zip",
                    "type": "string"
                  }
                }           
              }
            }
          }
        },
        {
          "title": "Deals",
          "type": "object",
          "properties": {
            "type": {
              "type": "string",
              "readonly": true,
              "options": {
                "hidden": true
            },
            "enum": [
              "Deals"
            ]
          },
          "data":{
            "title": "Data",
            "type": "array",
            "items":{
              "type": "object",
              "properties": {
                "id": {
                  "title": "Record Id",
                  "description": "Record Id",
                  "type": "string",
                  "minLength": 1
                },
                "Deal_Name": {
                  "title": "Deal Name",
                  "description": "Deal Name",
                  "type": "string"
                },
                "Stage": {
                  "title": "Stage",
                  "description": "Stage",
                  "type": "string",
                  "enum": ["Qualification", "Needs Analysis", "Proposal/Price Quote", "Negotiation/Review", "Closed Won", "Closed Lost"]
                },
                "Closing_Date": {
                  "title": "Closing Date (yyyy-MM-dd)",
                  "description": "Closing Date in Specified Format",
                  "type": "string"
                },
                "Pipeline": {
                  "title": "Pipeline",
                  "description": "Pipeline",
                  "type": "string"              
                },
                "Amount": {
                  "title": "Amount",
                  "description": "Amount",
                  "type": "string"                  
                }
              }
            }
          }
        }
      },
      {
        "title": "Companies",
        "type": "object",
        "properties": {
          "type": {
            "type": "string",
            "readonly": true,
            "options": {
              "hidden": true
          },
          "enum": [
            "Companies"
          ]
        },
        "data":{
          "title": "Data",
          "type": "array",
          "items":{
            "type": "object",
            "properties": {
              "id": {
                "title": "Record Id",
                "description": "Record Id",
                "type": "string",
                "minLength": 1
              },
              "Account_Name": {
                "title": "Account Name",
                "description": "Account Name",
                "type": "string",
              },
              "Phone": {
                "title": "Phone",
                "description": "Phone",
                "type": "string"                
              },
              "Website": {
                "title": "Website",
                "description": "Website",
                "type": "string"                
              },
              "Description": {
                "title": "Description",
                "description": "Description",
                "type": "string"                
              },
              "Billing_Street": {
                "title": "Billing Street",
                "description": "Billing Street",
                "type": "string"                
              },
              "Billing_City": {
                "title": "Billing City",
                "description": "Billing City",
                "type": "string"                
              },
              "Billing_State": {
                "title": "Billing State",
                "description": "Billing State",
                "type": "string"                
              },
              "Billing_Country": {
                "title": "Billing Country",
                "description": "Billing Country",
                "type": "string"                
              },
              "Billing_Code": {
                "title": "Billing Code",
                "description": "Billing Code",
                "type": "string"                
              }
            }
          }
        }
      }
    },
    {
      "title": "Products",
      "type": "object",
      "properties": {
        "type": {
          "type": "string",
          "readonly": true,
          "options": {
            "hidden": true
        },
        "enum": [
          "Products"
        ]
      },
      "data":{
        "title": "Data",
        "type": "array",
        "items":{
          "type": "object",
          "properties": {
            "id": {
              "title": "Record Id",
              "description": "Record Id",
              "type": "string",
              "minLength": 1
            },
            "Product_Name": {
              "title": "Product Name",
              "description": "Product Name",
              "type": "string"
            },
            "Product_Code": {
              "title": "Product Code",
              "description": "Product Code",
              "type": "string"                
            },
            "Product_Category": {
              "title": "Product Category",
              "description": "Product Category",
              "type": "string",
              "enum": ["", "Hardware", "Software", "CRM Applications"]                
            },
            "Unit_Price": {
              "title": "Unit Price",
              "description": "Unit Price",
              "type": "string"                
            },
            "Product_Active": {
              "title": "Product Active",
              "description": "Product Active",
              "type": "boolean"                
            }
          }
        }
      }
    }
  }
      ]
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_name": {
      "type": "Contacts",
      "data": [
        {
          "id": "302774000000223840",
          "Mailing_State":"Karnataka"
        }
      ]
    }
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.module_name.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_name.type,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "PUT",
      json: jsonData
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
