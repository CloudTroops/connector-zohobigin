module.exports = {

  name: "update_records",

  title: "Update Records",

  description: "To update existing entities in the module",
  version: "v1",

  input:{
    title: "Update Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "data":{
        "title": "data",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "data": [
      {
        "id": "302774000000223840",
        "Mailing_State":"Karnataka"
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "PUT",
      json: jsonData
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
