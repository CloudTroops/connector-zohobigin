module.exports = {

  name: "delete_user",

  title: "Delete User",

  description: "To delete a user from your organization",
  version: "v1",

  input:{
    title: "Delete User",
    type: "object",
    properties: {
      "user_id":{
        "title": "user_id",
        "type": "string",
        "displayTitle": "User Id",
        "minLength":1
      }

    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "users":{
        "title": "users",
        "type": "any",
        "displayTitle": "Users"
      }
    }
  },

  mock_input:{
    "user_id": "302774000000217002"
  },

  execute: function(input, output){
    
    let request = require('request');
    
    request({
      url: "https://www.zohoapis.in/bigin/v1/users/" + input.user_id,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
      },
      method: "DELETE",      
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
