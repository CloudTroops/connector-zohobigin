module.exports = {

  name: "get_notes_data",

  title: "Get Notes Data",

  description: "To get the list of notes",
  version: "v1",

  input:{
    title: "Get Notes Data",
    type: "object",
    properties: {
      "page":{
        "title": "page",
        "type": "number",
        "displayTitle": "Page"
      },
      "per_page":{
        "title": "per_page",
        "type": "number",
        "displayTitle": "Per Page"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{},

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      
    }

    if (input.page){
      data["page"] = input.page 
    }

    if (input.per_page){
      data["per_page"] = input.per_page 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/Notes",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "GET",
      qs: data 
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
