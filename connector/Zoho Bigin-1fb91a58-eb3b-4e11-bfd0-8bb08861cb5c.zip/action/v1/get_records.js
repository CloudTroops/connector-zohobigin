module.exports = {

  name: "get_records",

  title: "Get Records",

  description: "To get the list of available records from a module",
  version: "v1",

  input:{
    title: "Get Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "fields":{
        "title": "fields",
        "type": "string",
        "displayTitle": "Comma Separated Fields"
      },
      "sort_order":{
        "title": "sort_order",
        "type": "string",
        "displayTitle": "Sort Order"
      },
      "sort_by":{
        "title": "sort_by",
        "type": "string",
        "displayTitle": "Sort By"
      },
      "approved":{
        "title": "approved",
        "type": "string",
        "displayTitle": "Approved"
      },
      "page":{
        "title": "page",
        "type": "number",
        "displayTitle": "Page"
      },
      "per_page":{
        "title": "per_page",
        "type": "number",
        "displayTitle": "Per Page"
      },
      "cvid":{
        "title": "cvid",
        "type": "string",
        "displayTitle": "Custom View Id"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {

    }

    if (input.fields)
    {
      data["fields"] = input.fields
    }
    if (input.sort_order)
    {
      data["sort_order"] = input.sort_order
    }
    if (input.sort_by)
    {
      data["sort_by"] = input.sort_by
    }
    if (input.approved)
    {
      data["approved"] = input.approved
    }
    if (input.page)
    {
      data["page"] = input.page
    }
    if (input.per_page)
    {
      data["per_page"] = input.per_page
    }
    if (input.cvid)
    {
      data["cvid"] = input.cvid
    }   

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
