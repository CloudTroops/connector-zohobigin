module.exports = {

  name: "get_users_data",

  title: "Get Users Data",

  description: "To retrieve the users data specified in the API request",
  version: "v1",

  input:{
    title: "Get Users Data",
    type: "object",
    properties: {
      "type":{
        "title": "type",
        "type": "string",
        "enum": ["AllUsers", "ActiveUsers", "DeactiveUsers", "ConfirmedUsers", "NotConfirmedUsers", "DeletedUsers", "ActiveConfirmedUsers", "AdminUsers", "ActiveConfirmedAdmins", "CurrentUser"],
        "displayTitle": "Type",
        "minLength": 1
      },
      "page":{
        "title": "page",
        "type": "number",
        "displayTitle": "Page"
      },
      "per_page":{
        "title": "per_page",
        "type": "number",
        "displayTitle": "Per Page"
      }

    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "users":{
        "title": "users",
        "type": "any",
        "displayTitle": "Users"
      }
    }
  },

  mock_input:{
    "type": "AllUsers"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "type": input.type      
    }

    if (input.page){
      data["page"] = input.page 
    }

    if (input.per_page){
      data["per_page"] = input.per_page 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/users",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
