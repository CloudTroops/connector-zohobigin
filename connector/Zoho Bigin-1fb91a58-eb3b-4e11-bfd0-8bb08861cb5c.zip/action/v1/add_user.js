module.exports = {

  name: "add_user",

  title: "Add User",

  description: "To add a user to your organization",
  version: "v1",

  input:{
    title: "Add User",
    type: "object",
    properties: {
      "users":{
        "title": "users",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "first_name":{
              "title": "first_name",
              "type": "string",
              "displayTitle": "First Name"
            },
            "last_name":{
              "title": "last_name",
              "type": "string",
              "displayTitle": "Last Name",
              "minLength":1
            },
            "email":{
              "title": "email",
              "type": "string",
              "displayTitle": "Email",
              "minLength":1
            },
            "role":{
              "title": "role",
              "type": "string",
              "displayTitle": "Role",
              "minLength":1
            },
            "profile":{
              "title": "profile",
              "type": "string",
              "displayTitle": "Profile",
              "minLength":1
            }
          }      
          
        }

      }
      
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "users":{
        "title": "users",
        "type": "any",
        "displayTitle": "Users"
      }

    }
  },

  mock_input:{
    "users": [
      {
        "role": "302774000000223855",
        "first_name": "First",
        "email": "first.last@abcl.com",
        "profile": "302774000000031160",
        "last_name": "Last"
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "users": input.users
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/users",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "POST",
      json: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
