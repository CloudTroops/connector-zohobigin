module.exports = {

  name: "get_record_count_for_a_tag",

  title: "Get Record Count For A Tag",

  description: "To get the total number of records under a tag",
  version: "v1",

  input:{
    title: "Get Record Count For A Tag",
    type: "object",
    properties: {
      "tag_id":{
        "title": "tag_id",
        "type": "string",
        "displayTitle": "Tag Id",
        "minLength": 1
      },
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength": 1
      }      
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "count":{
        "title": "count",
        "type": "number",
        "displayTitle": "Count"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "tag_id": "302774000000224005"
  },

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/tags/" + input.tag_id + "/actions/records_count",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "GET",
      qs:{
        module: input.module_api_name    
      }     
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
