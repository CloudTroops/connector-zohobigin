module.exports = {

  name: "update_related_records",

  title: "Update Related Records",

  description: "To update the relation between the records",
  version: "v1",

  input:{
    title: "Update Related Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "record_id":{
        "title": "record_id",
        "type": "string",
        "displayTitle": "Record Id",
        "minLength":1        
      },
      "related_list_api_name":{
        "title": "related_list_api_name",
        "type": "string",
        "displayTitle": "Related List API Name",
        "minLength":1        
      },
      "related_record_id":{
        "title": "related_record_id",
        "type": "string",
        "displayTitle": "Related Record Id",
        "minLength":1        
      },
      "data":{
        "title": "data",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "id":{
              "title": "id",
              "type": "string",
              "displayTitle": "Id",
              "minLength":1        
            }            
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "record_id": "302774000000223767",
    "related_list_api_name": "Notes",
    "related_record_id": "302774000000223781",
    "data":[
      {
        "id":"302774000000223876",
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name + "/" + input.record_id + "/" + input.related_list_api_name + "/" + input.related_record_id,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "PUT",
      json: jsonData      
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
