module.exports = {

  name: "search_records",

  title: "Search Records",

  description: "To retrieve the records that match your search criteria",
  version: "v1",

  input:{
    title: "Search Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "search_criteria":{
        "title": "search_criteria",
        "type": "string",
        "displayTitle": "Search Criteria"        
      },
      "email":{
        "title": "email",
        "type": "string",
        "displayTitle": "Email"        
      },
      "phone":{
        "title": "phone",
        "type": "string",
        "displayTitle": "Phone"        
      },
      "word":{
        "title": "word",
        "type": "string",
        "displayTitle": "Word"        
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "email": "sukeshmaya@gmail.com"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
          
    }

    if (input.search_criteria){
      data["criteria"] = input.search_criteria 
    }

    if (input.email){
      data["email"] = input.email 
    }

    if (input.phone){
      data["phone"] = input.phone 
    }

    if (input.word){
      data["word"] = input.word 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name + "/search",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs: data    
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
