module.exports = {

  name: "remove_tags_from_records",

  title: "Remove Tags From Records",

  description: "To delete the tags associated with records",
  version: "v1",

  input:{
    title: "Remove Tags From Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength": 1
      },
      "record_ids":{
        "title": "record_ids",
        "type": "string",
        "displayTitle": "Comma Separated Record Ids",
        "minLength": 1
      },
      "tag_names":{
        "title": "tag_names",
        "type": "string",
        "displayTitle": "Comma Separated Tag Names"        
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "record_ids": "302774000000223767",
    "tag_names": "Important"    
  },

  execute: function(input, output){
   
    let request = require('request');

    var data = {
      "ids": input.record_ids      
    }

    if (input.tag_names){
      data["tag_names"] = input.tag_names 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name + "/actions/remove_tags",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "POST",
      qs: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
