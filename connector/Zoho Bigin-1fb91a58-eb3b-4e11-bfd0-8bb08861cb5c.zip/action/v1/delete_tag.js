module.exports = {

  name: "delete_tag",

  title: "Delete Tag",

  description: "To delete a tag from a module",
  version: "v1",

  input:{
    title: "Delete Tag",
    type: "object",
    properties: {
      "tag_id":{
        "title": "tag_id",
        "type": "string",
        "displayTitle": "Tag Id",
        "minLength": 1
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "tags":{
        "title": "tags",
        "type": "any",
        "displayTitle": "Tags"
      }
    }
  },

  mock_input:{
    "tag_id": "302774000000224006"
  },

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/tags/" + input.tag_id,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "DELETE"
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
