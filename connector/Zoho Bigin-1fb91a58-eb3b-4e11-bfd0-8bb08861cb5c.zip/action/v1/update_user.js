module.exports = {

  name: "update_user",

  title: "Update User",

  description: "To update the details of a user of your organization",
  version: "v1",

  input:{
    title: "Update User",
    type: "object",
    properties: {
      "users":{
        "title": "users",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "id":{
              "title": "id",
              "type": "string",
              "displayTitle": "Id",
              "minLength":1
            },
            "phone":{
              "title": "phone",
              "type": "string",
              "displayTitle": "Phone"
            },
            "email":{
              "title": "email",
              "type": "string",
              "displayTitle": "Email"
            },
            "dob":{
              "title": "dob",
              "type": "string",
              "displayTitle": "Dob"
            },
            "role":{
              "title": "role",
              "type": "string",
              "displayTitle": "Role"
            },
            "profile":{
              "title": "profile",
              "type": "string",
              "displayTitle": "Profile"
            },
            "country_locale":{
              "title": "country_locale",
              "type": "string",
              "displayTitle": "Country Locale"
            },
            "time_format":{
              "title": "time_format",
              "type": "string",
              "displayTitle": "Time Format"
            },
            "time_zone":{
              "title": "time_zone",
              "type": "string",
              "displayTitle": "Time Zone"
            },
            "status":{
              "title": "status",
              "type": "string",
              "displayTitle": "Status"
            },
            "city":{
              "title": "city",
              "type": "string",
              "displayTitle": "City"
            },
            "state":{
              "title": "state",
              "type": "string",
              "displayTitle": "State"
            },
            "zip":{
              "title": "zip",
              "type": "string",
              "displayTitle": "Zip"
            }
          }
        }
      }

    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "users":{
        "title": "users",
        "type": "any",
        "displayTitle": "Users"
      }

    }
  },

  mock_input:{
    "users": [
      {
      "id": "302774000000217001",
      "phone": "123456789",
      "zip": "500013"
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "users": input.users
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/users",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "PUT",
      json: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
