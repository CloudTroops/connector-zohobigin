module.exports = {

  name: "create_notes",

  title: "Create Notes",

  description: "To add new notes to modules",
  version: "v1",

  input:{
    title: "Create Notes",
    type: "object",
    properties: {
      "data":{
        "title": "data",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "Note_Title":{
              "title": "Note_Title",
              "type": "string",
              "displayTitle": "Note Title"
            },
            "Note_Content":{
              "title": "Note_Content",
              "type": "string",
              "displayTitle": "Note Content",
              "minLength": 1
            },
            "Parent_Id":{
              "title": "Parent_Id",
              "type": "string",
              "displayTitle": "Parent Id",
              "minLength": 1
            },
            "se_module":{
              "title": "se_module",
              "type": "string",
              "displayTitle": "Se Module",
              "minLength": 1
            }            
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
      "data": [
         {
              "Note_Title": "Contacted",
              "Note_Content": "Need to do further tracking",
              "Parent_Id": "302774000000223767",
              "se_module": "Contacts"
          }
      ]  
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/Notes",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "POST",
      json: jsonData
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
