module.exports = {

  name: "get_layouts_metadata",

  title: "Get Layouts Metadata",

  description: "To get details of the layouts associated with a particular module",
  version: "v1",

  input:{
    title: "Get Layouts Metadata",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "layouts":{
        "title": "layouts",
        "type": "any",
        "displayTitle": "Layouts"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts"
  },

  execute: function(input, output){
   
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/layouts",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET",
      qs:{
        module: input.module_api_name
      }
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
