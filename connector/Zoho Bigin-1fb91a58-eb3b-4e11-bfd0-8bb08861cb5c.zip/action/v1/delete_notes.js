module.exports = {

  name: "delete_notes",

  title: "Delete Notes",

  description: "To delete notes",
  version: "v1",

  input:{
    title: "Delete Notes",
    type: "object",
    properties: {
      "ids":{
        "title": "ids",
        "type": "string",
        "displayTitle": "Comma Separated Ids",
        "minLength":1
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "ids": "302774000000223782"
  },

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/Notes",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "DELETE",
      qs:{
        ids: input.ids        
      }     
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
