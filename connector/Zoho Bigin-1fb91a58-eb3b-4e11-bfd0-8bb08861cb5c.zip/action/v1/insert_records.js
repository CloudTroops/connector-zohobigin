module.exports = {

  name: "insert_records",

  title: "Insert Records",

  description: "To add new entities to a module",
  version: "v1",

  input:{
    title: "Insert Records",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength":1
      },
      "data":{
        "title": "data",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "data": [
      {
          "Last_Name": "Daly",
          "First_Name": "Paul",
          "Email": "p.daly@abc.com"
      },
      {
          "Last_Name": "Dolan",
          "First_Name": "Brian",
          "Email": "brian@xyz.com"
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "POST",
      json: jsonData
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
