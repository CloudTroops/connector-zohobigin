module.exports = {

  name: "update_notes",

  title: "Update Notes",

  description: "To update an existing note",
  version: "v1",

  input:{
    title: "Update Notes",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength": 1
      },
      "record_id":{
        "title": "record_id",
        "type": "string",
        "displayTitle": "Record Id",
        "minLength": 1
      },
      "note_id":{
        "title": "note_id",
        "type": "string",
        "displayTitle": "Note Id",
        "minLength": 1
      },
      "data":{
        "title": "data",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "Note_Title":{
              "title": "Note_Title",
              "type": "string",
              "displayTitle": "Note Title"
            },
            "Note_Content":{
              "title": "Note_Content",
              "type": "string",
              "displayTitle": "Note Content",
            }            
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "data":{
        "title": "data",
        "type": "any",
        "displayTitle": "Data"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "record_id": "302774000000223767",
    "note_id": "302774000000223781",
    "data": [
      {
           "Note_Title": "Contacted",
           "Note_Content": "Tracking done. Happy with the customer"
       }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var jsonData = {
      "data": input.data
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/" + input.module_api_name + "/" + input.record_id + "/Notes/" + input.note_id,
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "PUT",
      json: jsonData
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
