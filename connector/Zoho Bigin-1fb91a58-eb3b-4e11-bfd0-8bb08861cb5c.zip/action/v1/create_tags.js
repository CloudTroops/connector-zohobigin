module.exports = {

  name: "create_tags",

  title: "Create Tags",

  description: "To create tags",
  version: "v1",

  input:{
    title: "Create Tags",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength": 1
      },
      "tags":{
        "title": "tags",
        "type": "array",
        "items": {
          "type":"object",
          "properties":{
            "name":{
              "title": "name",
              "type": "string",
              "displayTitle": "Name",
              "minLength": 1
            }        
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "tags":{
        "title": "tags",
        "type": "any",
        "displayTitle": "Tags"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts",
    "tags":[
      {
      "name": "Not Important"
      }
    ]
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "tags": input.tags
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/tags",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "application/json"
      },
      method: "POST",
      qs: {
        module: input.module_api_name
      },
      json: data
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
