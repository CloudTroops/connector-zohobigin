module.exports = {

  name: "delete_notifications",

  title: "Delete Notifications",

  description: "To stop all the instant notifications enabled by the user for a channel",
  version: "v1",

  input:{
    title: "Delete Notifications",
    type: "object",
    properties: {
      "channel_ids":{
        "title": "channel_ids",
        "type": "string",
        "displayTitle": "Comma Separated Channel Ids",
        "minLength": 1
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "watch":{
        "title": "watch",
        "type": "any",
        "displayTitle": "Watch"
      }
    }
  },

  mock_input:{
    "channel_ids": "1000000068002"
  },

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/actions/watch",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "DELETE",
      qs:{
        channel_ids: input.channel_ids
      }     
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
