module.exports = {

  name: "get_notification_details",

  title: "Get Notification Details",

  description: "To get the details of the notifications enabled by the user",
  version: "v1",

  input:{
    title: "Get Notification Details",
    type: "object",
    properties: {
      "page":{
        "title": "page",
        "type": "number",
        "displayTitle": "Page"
      },
      "per_page":{
        "title": "per_page",
        "type": "number",
        "displayTitle": "Per Page"
      },
      "channel_id":{
        "title": "channel_id",
        "type": "number",
        "displayTitle": "Channel Id",
        "minLength": 1
      },
      "module":{
        "title": "module",
        "type": "string",
        "displayTitle": "Module"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "watch":{
        "title": "watch",
        "type": "any",
        "displayTitle": "Watch"
      }
    }
  },

  mock_input:{
    "channel_id": "1000000068001"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "channel_id": input.channel_id      
    }

    if (input.page){
      data["page"] = input.page 
    }

    if (input.per_page){
      data["per_page"] = input.per_page 
    }

    if (input.module){
      data["module"] = input.module 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/actions/watch",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "GET",
      qs: data     
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
