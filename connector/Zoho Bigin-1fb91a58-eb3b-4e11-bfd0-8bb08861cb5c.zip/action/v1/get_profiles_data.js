module.exports = {

  name: "get_profiles_data",

  title: "Get Profiles Data",

  description: "To retrieve the data of profiles of your organization",
  version: "v1",

  input:{
    title: "Get Profiles Data",
    type: "object",
    properties: {

    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "profiles":{
        "title": "profiles",
        "type": "any",
        "displayTitle": "Profiles"
      }
    }
  },

  mock_input:{},

  execute: function(input, output){
    
    let request = require('request');

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/profiles",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
      },
      method: "GET"
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
