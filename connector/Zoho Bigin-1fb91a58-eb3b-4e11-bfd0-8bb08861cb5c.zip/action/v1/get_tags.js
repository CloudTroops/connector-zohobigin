module.exports = {

  name: "get_tags",

  title: "Get Tags",

  description: "To display all the tags from a specific module in an organization",
  version: "v1",

  input:{
    title: "Get Tags",
    type: "object",
    properties: {
      "module_api_name":{
        "title": "module_api_name",
        "type": "string",
        "displayTitle": "Module API Name",
        "minLength": 1
      },
      "my_tags":{
        "title": "my_tags",
        "type": "string",
        "displayTitle": "My Tags",
        "enum": ["", "true", "false"]
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "tags":{
        "title": "tags",
        "type": "any",
        "displayTitle": "Tags"
      },
      "info":{
        "title": "info",
        "type": "any",
        "displayTitle": "Info"
      }
    }
  },

  mock_input:{
    "module_api_name": "Contacts"
  },

  execute: function(input, output){
    
    let request = require('request');

    var data = {
      "module": input.module_api_name      
    }

    if (input.my_tags){
      data["my_tags"] = input.my_tags 
    }

    request({
      url: "https://www.zohoapis.in/bigin/v1/settings/tags",
      headers: {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token
        
      },
      method: "GET",
      qs: data 
    },
      function(err, res, body){
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
  }

}
