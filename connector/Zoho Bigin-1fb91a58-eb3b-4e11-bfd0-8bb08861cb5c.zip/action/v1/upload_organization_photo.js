module.exports = {

  name: "upload_organization_photo",

  title: "Upload Organization Photo",

  description: "To upload the brand logo or image of the organization",
  version: "v1",

  input:{
    title: "Upload Organization Photo",
    type: "object",
    properties: {
      "upload_file":{
        "title": "upload_file",
        "type": "file",
        "displayTitle": "Upload File"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      
    }
  },

  mock_input:{},

  execute: function(input, output){
    
    let fs = require('fs');
    let request = require('request');

    var option = {
      "method": "POST",
      "headers": {
        Authorization: "Zoho-oauthtoken " + input.auth.access_token,
        "ContentType": "multipart/form-data"
      },
      "formData": {
        "file": fs.createReadStream(input.upload_file)
      },
      "url": "https://www.zohoapis.in/bigin/v1/org/photo",      
  }

    request(option, function(error, res, body) {
        if (err){
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string'){
              body = JSON.parse(body);
            }
            return output(null, body);
          }
          else {
            if (body && body.errors){
              return output(JSON.stringify(body.errors))
            }
            return output(JSON.stringify(body))
          }

        }
      }

    );
    
  }

}
