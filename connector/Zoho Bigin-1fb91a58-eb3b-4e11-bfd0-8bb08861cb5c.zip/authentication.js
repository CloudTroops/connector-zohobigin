module.exports = {
  label: "Connect to ZohoBigin",
  mock_input: {
    access_token: "1000.ee50004cf780605655fc608ace9266bc.0edce7867826b9dcb2091c2ea7d54a26"
  },
  oauth: "zoho_bigin_oauthv2_e657dee020",
  validate: function (input, output) {
    // auth credentials will be available in input.auth.access_token
    // callback pattern
    // output(error, success)
    output(null, true)
  }
}